
/*
 *  spchksum.h
 *  Define a SPHERE checksum
 */

#ifndef _SPCHKSUM_H_
#define _SPCHKSUM_H_

typedef unsigned short SP_CHECKSUM;

#endif
