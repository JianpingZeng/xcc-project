/* File: min.h */

#ifndef MIN
#define MIN(x,y)		((x) < (y) ? (x) : (y))
#endif
