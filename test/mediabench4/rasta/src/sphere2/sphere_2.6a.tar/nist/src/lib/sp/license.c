#include <stdio.h>

void license() {
  printf("SHORTEN SOFTWARE LICENSE\n");
  printf("\n");
  printf("This software is being provided to you, the LICENSEE, by Tony Robinson\n");
  printf("under the following license.  By obtaining, using and/or copying this\n");
  printf("software, you agree that you have read, understood, and will comply with\n");
  printf("these terms and conditions:\n");
  printf("\n");
  printf("This software may not be sold or incorporated into any product which is\n");
  printf("sold without prior permission from the author.  When no charge is made,\n");
  printf("this software may be copied and distributed freely.\n");
  printf("\n");
  printf("Permission is granted to use this software for decoding and\n");
  printf("non-commercial encoding.  Commercial encoding licences may be negotiated\n");
  printf("through SoftSound Ltd (email shorten@softsound.com).\n");
  printf("\n");
  printf("DISCLAIMER\n");
  printf("\n");
  printf("This software carries no warranty, expressed or implied.  The user\n");
  printf("assumes all risks, known or unknown, direct or indirect, which involve\n");
  printf("this software in any way.\n");
  printf("\n");
  printf("Dr AJ Robinson  Tel +44 1223 332815  Fax +44 1223 332662  Email ajr4@cam.ac.uk\n");
  printf("Cambridge University Engineering Department, Trumpington Street, Cambridge, UK\n");
}
